<?php $__env->startSection('form-title'); ?>
    <?php if(isset($data)): ?>
        Ubah Data <?php echo e($settings['title']); ?>

    <?php else: ?>
        Tambah Data <?php echo e($settings['title']); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('form'); ?>
    <?php if(isset($data)): ?>
        <input type="hidden" name="_method" value="PUT">
    <?php endif; ?>
    <div class="form-group">
      <label for="nama_pelanggan" class="form-label">Nama Pelanggan <span class="text-danger">*</span> </label>
      <input class="form-control" type="text" name="nama_pelanggan" required value="<?php echo e(old('nama_pelanggan',@$data->nama_pelanggan)); ?>">
      <?php $__errorArgs = ['nama_pelanggan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger"><?php echo e($message); ?></strong>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
      <label for="no_telp" class="form-label">No Telp <span class="text-danger">*</span> </label>
      <input class="form-control phone" type="text" name="no_telp" required value="<?php echo e(old('no_telp',@$data->no_telp)); ?>">
      <?php $__errorArgs = ['no_telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger"><?php echo e($message); ?></strong>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
      <label for="alamat" class="form-label">Alamat</label>
      <textarea name="alamat" class="form-control"><?php echo e(old('alamat',@$data->alamat)); ?></textarea>
      <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger"><?php echo e($message); ?></strong>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/pelanggan/form.blade.php ENDPATH**/ ?>