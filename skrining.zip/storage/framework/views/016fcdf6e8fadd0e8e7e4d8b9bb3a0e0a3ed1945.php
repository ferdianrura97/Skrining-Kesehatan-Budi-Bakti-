<form action="<?php echo e(route($settings['route'].'.destroy',$data->id)); ?>" method="POST" class="delete-data" onsubmit="return confirm('Yakin ingin menghapus data ini?');">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="_method" value="DELETE">
  <td>
    <?php if(@$settings['ubah'] || !isset($settings['ubah'])): ?>
    <a type="button" class="btn btn-outline-warning btn-sm" href="<?php echo e(route($settings['route'].'.edit',$data->id)); ?>" > Edit</a>
    <?php endif; ?>
    <?php if(@$settings['hapus'] || !isset($settings['hapus'])): ?>
      <button type="submit" class="m-2 btn btn-outline-danger btn-sm"> Hapus</button>
    <?php endif; ?>
  </td>
</form><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/layouts/include/basic-action.blade.php ENDPATH**/ ?>