<aside class="sidebar sidebar-default navs-rounded-all ">
    <div class="sidebar-header d-flex align-items-center justify-content-start">
        <a href="<?php echo e(route('dashboard')); ?>" class="navbar-brand">
            <!--Logo start-->
            <svg width="30" class="" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="-0.757324" y="19.2427" width="28" height="4" rx="2" transform="rotate(-45 -0.757324 19.2427)"
                    fill="currentColor" />
                <rect x="7.72803" y="27.728" width="28" height="4" rx="2" transform="rotate(-45 7.72803 27.728)"
                    fill="currentColor" />
                <rect x="10.5366" y="16.3945" width="16" height="4" rx="2" transform="rotate(45 10.5366 16.3945)"
                    fill="currentColor" />
                <rect x="10.5562" y="-0.556152" width="28" height="4" rx="2" transform="rotate(45 10.5562 -0.556152)"
                    fill="currentColor" />
            </svg>
            <!--logo End-->
            <h4 class="logo-title"><?php echo e(env('APP_NAME')); ?></h4>
        </a>
        <div class="sidebar-toggle" data-toggle="sidebar" data-active="true">
            <i class="icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M4.25 12.2744L19.25 12.2744" stroke="currentColor" stroke-width="1.5"
                        stroke-linecap="round" stroke-linejoin="round"></path>
                    <path d="M10.2998 18.2988L4.2498 12.2748L10.2998 6.24976" stroke="currentColor" stroke-width="1.5"
                        stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
            </i>
        </div>
    </div>
    <div class="sidebar-body pt-0 data-scrollbar">
        <div class="sidebar-list">
            <!-- Sidebar Menu Start -->
            <ul class="navbar-nav iq-main-menu" id="sidebar-menu">
                <li class="nav-item static-item">
                    <a class="nav-link static-item disabled" href="#" tabindex="-1">
                        <span class="default-icon">Menus</span>
                        <span class="mini-icon">M</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e((request()->is('/')) ? 'active' : ''); ?>" aria-current="page"
                        href="<?php echo e(route('dashboard')); ?>">
                        <i class="fa-solid fa-house"></i>
                        <span class="item-name">Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="collapse" href="#masterdata-menu" role="button"
                        aria-expanded="false" aria-controls="masterdata-menu">
                        <i class="fa-solid fa-database"></i>

                        <span class="item-name">Master Data</span>
                        <i class="right-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 5l7 7-7 7" />
                            </svg>
                        </i>
                    </a>
                    <ul class="sub-nav collapse" id="masterdata-menu" data-bs-parent="#sidebar-menu">
                        <li class="nav-item">
                            <a class="nav-link  <?php echo e((request()->is('akun-kas*')) ? 'active' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('akun-kas.index')); ?>">
                                <i class="icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10" viewBox="0 0 24 24"
                                        fill="currentColor">
                                        <g>
                                            <circle cx="12" cy="12" r="8" fill="currentColor"></circle>
                                        </g>
                                    </svg>
                                </i>
                                <i class="sidenav-mini-icon"> A </i>
                                <span class="item-name"> Akun Kas </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link  <?php echo e((request()->is('pelanggan*')) ? 'active' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('pelanggan.index')); ?>">
                                <i class="icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10" viewBox="0 0 24 24"
                                        fill="currentColor">
                                        <g>
                                            <circle cx="12" cy="12" r="8" fill="currentColor"></circle>
                                        </g>
                                    </svg>
                                </i>
                                <i class="sidenav-mini-icon"> P </i>
                                <span class="item-name"> Pelanggan </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link  <?php echo e((request()->is('supplier*')) ? 'active' : ''); ?>" aria-current="page"
                                href="<?php echo e(route('supplier.index')); ?>">
                                <i class="icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10" viewBox="0 0 24 24"
                                        fill="currentColor">
                                        <g>
                                            <circle cx="12" cy="12" r="8" fill="currentColor"></circle>
                                        </g>
                                    </svg>
                                </i>
                                <i class="sidenav-mini-icon"> S </i>
                                <span class="item-name"> Supplier </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link  <?php echo e((request()->is('produk*')) ? 'active' : ''); ?>" aria-current="page"
                                href="<?php echo e(route('produk.index')); ?>">
                                <i class="icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10" viewBox="0 0 24 24"
                                        fill="currentColor">
                                        <g>
                                            <circle cx="12" cy="12" r="8" fill="currentColor"></circle>
                                        </g>
                                    </svg>
                                </i>
                                <i class="sidenav-mini-icon"> P </i>
                                <span class="item-name"> Produk </span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e((request()->is('penjualan*')) ? 'active' : ''); ?>" aria-current="page"
                        href="<?php echo e(route('penjualan.index')); ?>">
                        <i class="fa-solid fa-shop"></i>
                        <span class="item-name">Penjualan</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e((request()->is('pembelian*')) ? 'active' : ''); ?>" aria-current="page"
                        href="<?php echo e(route('pembelian.index')); ?>">
                        <i class="fa-solid fa-cart-plus"></i>
                        <span class="item-name">Pembelian</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e((request()->is('pengeluaran*')) ? 'active' : ''); ?>" aria-current="page"
                        href="<?php echo e(route('pengeluaran.index')); ?>">
                        <i class="fa-solid fa-comment-dollar"></i>
                        <span class="item-name">Pengeluaran</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="collapse" href="#settings-menu" role="button"
                        aria-expanded="false" aria-controls="settings-menu">
                        <i class="fa-solid fa-gears"></i>

                        <span class="item-name">Settings</span>
                        <i class="right-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 5l7 7-7 7" />
                            </svg>
                        </i>
                    </a>
                    <ul class="sub-nav collapse" id="settings-menu" data-bs-parent="#sidebar-menu">
                        <li class="nav-item">
                            <a class="nav-link  <?php echo e((request()->is('level*')) ? 'active' : ''); ?>" aria-current="page"
                                href="<?php echo e(route('level.index')); ?>">
                                <i class="icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10" viewBox="0 0 24 24"
                                        fill="currentColor">
                                        <g>
                                            <circle cx="12" cy="12" r="8" fill="currentColor"></circle>
                                        </g>
                                    </svg>
                                </i>
                                <i class="sidenav-mini-icon"> L </i>
                                <span class="item-name"> Level </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link  <?php echo e((request()->is('user*')) ? 'active' : ''); ?>" aria-current="page"
                                href="<?php echo e(route('user.index')); ?>">
                                <i class="icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="10" viewBox="0 0 24 24"
                                        fill="currentColor">
                                        <g>
                                            <circle cx="12" cy="12" r="8" fill="currentColor"></circle>
                                        </g>
                                    </svg>
                                </i>
                                <i class="sidenav-mini-icon"> U </i>
                                <span class="item-name"> User </span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu End -->
        </div>
    </div>
    <div class="sidebar-footer"></div>
</aside><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/layouts/_sidebar.blade.php ENDPATH**/ ?>