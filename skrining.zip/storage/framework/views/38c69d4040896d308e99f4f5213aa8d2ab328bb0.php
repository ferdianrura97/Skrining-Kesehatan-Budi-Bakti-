

<?php $__env->startSection('breadcrumb'); ?>
<?php echo $__env->make('layouts.include._breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-sm-12">
     <div class="card">
        <div class="card-header d-flex justify-content-between">
           <div class="header-title">
              <h4 class="card-title"><?php echo e($settings['title']); ?></h4>
            </div>
            <?php if(Helper::cek_akses($settings['title'], 'Tambah')): ?>
               <a href="<?php echo e(route($settings['route'].'.create')); ?>" class="btn btn-sm btn-primary float-right">+ Tambah <?php echo e($settings['title']); ?></a>
            <?php endif; ?>
        </div>
        <div class="card-body">
           <div class="table-responsive">
              <table id="datatable" class="table" data-toggle="data-table">
                 <thead>
                    <tr>
                     <th>No</th>
                     <th>Nama Penyakit</th>
                     <th>Point</th>
                     <th>Aksi</th>
                    </tr>
                 </thead>
                 <tbody>
                  <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                     <td><?php echo e($data->id); ?></td>
                     <td><?php echo e($data->nama_penyakit); ?></td>
                     <td><?php echo e($data->point); ?></td>
                     <form action="<?php echo e(route($settings['route'].'.destroy',$data->id)); ?>" method="POST" class="delete-data" onsubmit="return confirm('Yakin ingin menghapus data ini?');">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="DELETE">
                        <td>
                          <?php if(@$settings['ubah'] || !isset($settings['ubah'])): ?>
                          <a type="button" class="btn btn-outline-warning btn-sm" href="<?php echo e(route($settings['route'].'.edit',$data->id)); ?>" > Edit</a>
                          <?php endif; ?>
                          <?php if(@$settings['hapus'] || !isset($settings['hapus'])): ?>
                            <button type="submit" class="m-2 btn btn-outline-danger btn-sm"> Hapus</button>
                          <?php endif; ?>
                        </td>
                      </form>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tfoot>
              </table>
           </div>
        </div>
     </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel\skrining\resources\views/penyakit/index.blade.php ENDPATH**/ ?>