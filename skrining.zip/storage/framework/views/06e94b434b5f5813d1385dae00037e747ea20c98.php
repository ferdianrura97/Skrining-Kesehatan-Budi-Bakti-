<?php $__env->startSection('form-title'); ?>
    <?php if(isset($data)): ?>
        Ubah Data <?php echo e($settings['title']); ?>

    <?php else: ?>
        Tambah Data <?php echo e($settings['title']); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
  .form-control{
    padding: .5rem 0.5rem !important;
  }
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('form'); ?>
    <?php if(isset($data)): ?>
        <input type="hidden" name="_method" value="PUT">
    <?php endif; ?>
    <div class="row">
      <div class="col-md-4">
        <div class="form-group">
          <label for="akun_kas_id" class="form-label">Bayar Dari <span class="text-danger">*</span> </label>
          <select class="form-control select2" name="akun_kas_id" tabindex="-1" required>
            <option value="">Pilih Akun</option>
            <?php $__currentLoopData = $akuns->where('kategori_akun_id', 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($akun->id); ?>" <?php if($akun->id == old('akun_kas_id',@$data->akun_kas_id)): ?> selected <?php endif; ?>><?php echo e($akun->nama_akun); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <?php $__errorArgs = ['akun_kas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
          <label for="no_pengeluaran" class="form-label">No Pengeluaran <span class="text-danger">*</span> </label>
          <input class="form-control" type="text" value="<?php echo e((@$data) ? $data->no_pengeluaran : \Helper::generateNoPengeluaran()); ?>" name="no_pengeluaran" required readonly>
          <?php $__errorArgs = ['no_pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>

      <div class="col-md-3">
        <div class="form-group">
          <label for="tgl_pengeluaran" class="form-label">Tgl Pengeluaran <span class="text-danger">*</span> </label>
          <input class="form-control" type="date" name="tgl_pengeluaran" required value="<?php echo e(date('Y-m-d')); ?>">
          <?php $__errorArgs = ['tgl_pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
          <label for="tgl_jatuh_tempo" class="form-label">Tgl Jatuh Tempo <span class="text-danger">*</span> </label>
          <input class="form-control" type="date" name="tgl_jatuh_tempo" required value="<?php echo e(date('Y-m-d')); ?>">
          <?php $__errorArgs = ['tgl_jatuh_tempo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
      <div class="col-md-5">
        <div class="form-group text-end primary">
          <h3>Total <span style="color: #3a57e8" id="total_tagihan">Rp. 0</span></h3>
        </div>
      </div>
    </div>

    <div class="row mb-5">
      <div class="col-md-12">
        <table class="table" style="font-size: 11px;">
          <thead>
            <tr>
              <th width="25%">Pengeluaran / Akun<span class="text-danger">*</span></th>
              <th width="50%">Deskripsi<span class="text-danger">*</span></th>
              <th width="20%">Biaya<span class="text-danger">*</span></th>
              <th width="2%"></th>
            </tr>
          </thead>
          <tbody>
            <?php if(isset($data)): ?>
            <?php $__currentLoopData = $data->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <select class="form-control select2" name="akun_id[]" tabindex="-1" required>
                  <option value="">Pilih Akun</option>
                  <?php $__currentLoopData = $akuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($akun->id); ?>" <?php if($akun->id == $detail->akun_id): ?> selected <?php endif; ?> ><?php echo e($akun->nama_akun); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['akun_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control" type="text" name="desc[]" required value="<?php echo e($detail->desc); ?>">
                <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control money" type="text" name="biaya[]" value="<?php echo e($detail->biaya); ?>" >
                <?php $__errorArgs = ['biaya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <a class="removeButton"><i class="fa-solid fa-minus"></i></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php else: ?>
            <tr>
              <td>
                <select class="form-control select2" name="akun_id[]" tabindex="-1" required>
                  <option value="">Pilih Akun</option>
                  <?php $__currentLoopData = $akuns->where('kategori_akun_id', 7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($akun->id); ?>"><?php echo e($akun->nama_akun); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['akun_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control" type="text" name="desc[]" required>
                <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control money" type="text" name="biaya[]" >
                <?php $__errorArgs = ['biaya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <a class="removeButton"><i class="fa-solid fa-minus"></i></a>
              </td>
            </tr>


            <?php endif; ?>


          </tbody>
        </table>
        <button type="button" class="btn btn-sm btn-primary addButton"> <i class="fa-solid fa-plus"></i> Tambah Biaya </button>
      </div>
    </div>

    <div class="row mb-5">
      <div class="col-md-3">
        <label for="catatan" class="form-label">Catatan </label>
        <textarea name="catatan" class="form-control"><?php echo e(old('catatan',@$data->catatan)); ?></textarea>
        <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <strong class="text-danger"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="offset-md-5 col-md-4">
        <div class="row">
          <div class="col-md-6">
            <p> Total </p>
            <p class="fw-bolder"> Uang Muka (Rp.) </p>
          </div>
          <div class="col-md-6 text-end">
            <p id="total"> 0 </p>
            <input style="width: 80%;" class="form-control money float-end text-end" type="text" name="uang_muka" value="<?php echo e(old('uang_muka',@$data->uang_muka)); ?>">
          </div>
          
          <div class="col-md-6">
            <h5 style="color: #8A92A5">Sisa Tagihan</h5>
          </div>
          <div class="col-md-6 text-end">
            <h5 style="color: #8A92A5" id="sisa_tagihan"> </h5>
          </div>
        </div>
      </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  $(document).ready(function(){

    // Function Wrapper

    /*
    Function Convert String To Number
    */
    function toNumber(string){
      return parseInt(string.replace(/\./g, ''))
    }

    /*
    Function Format Uang
    */
    function money(x) {
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    /*
    Function Hitung Keseluruhan Sub Total
    */
    function hitungTotal(){
      let total = 0;
      $('input[name="biaya[]"]').each(function(index, el) {
        total += toNumber($(this).val());
      });
      
      $('#total').html("Rp. " + money(total));

      const uangMuka = toNumber($('input[name="uang_muka"]').val());
      const sisaTagihan = total - (uangMuka ? uangMuka : 0);
      $('#sisa_tagihan').html("Rp. " + money(sisaTagihan));
      $('#total_tagihan').html("Rp. " + money(total));
    }

    function init(){
      $('.money').mask('000.000.000.000.000', {reverse: true});
      $('.phone').mask('0000-0000');
      $('.number').mask('0000000000000');

      $('input[name="biaya[]"]').keyup(function (e) { 
        hitungTotal();
      }); 

      $('input[name="uang_muka"]').keyup(function (e) { 
        hitungTotal();
      }); 
    }

    // End Function Wrapper

    $('aside.sidebar').addClass('sidebar-mini');

    let addButton = $('.addButton');
    let wrapper = $('tbody');
    let fieldHtml = `
    <tr>
        <td>
            <select class="form-control select2" name="akun_id[]" tabindex="-1" required>
              <option value="">Pilih Akun</option>
              <?php $__currentLoopData = $akuns->where('kategori_akun_id', 7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($akun->id); ?>"><?php echo e($akun->nama_akun); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['akun_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>
        <td>
            <input class="form-control" type="text" name="desc[]" required>
            <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>
        <td>
            <input class="form-control money" type="text" name="biaya[]">
            <?php $__errorArgs = ['biaya'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>
        <td>
          <a class="removeButton"><i class="fa-solid fa-minus"></i></a>
        </td>
    </tr>
    `;

    $(addButton).click(function(){
      $(wrapper).append(fieldHtml); //Add field html

      init();
    });

    $(wrapper).on('click', '.removeButton', function(e){
        e.preventDefault();
        $(this).parent().parent().remove(); //Remove field html
    });

    init();
    
    let isEditForm = "<?php echo e(@$data); ?>";
    if(isEditForm.length){
      hitungTotal();
    }

    
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/pengeluaran/form.blade.php ENDPATH**/ ?>