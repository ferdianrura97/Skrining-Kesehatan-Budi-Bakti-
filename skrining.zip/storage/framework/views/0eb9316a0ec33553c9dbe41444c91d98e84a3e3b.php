<?php $__env->startSection('form-title'); ?>
    <?php if(isset($data)): ?>
        Ubah Data <?php echo e($settings['title']); ?>

    <?php else: ?>
        Tambah Data <?php echo e($settings['title']); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('form'); ?>
    <?php if(isset($data)): ?>
        <input type="hidden" name="_method" value="PUT">
    <?php endif; ?>

    <div class="form-group">
        <label for="nama" class="label-control">Nama Staff <span class="text-danger">*</span></label>
        <input type="text" autocomplete="off" maxlength="200" class="form-control" name="nama" id="nama" placeholder="Nama Staff" required value="<?php echo e(old('nama',@$data->nama)); ?>">
        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    
    <div class="form-group">
        <label for="username" class="label-control">Username <span class="text-danger">*</span></label>
        <input type="text" autocomplete="off" maxlength="200" class="form-control" name="username" id="username" placeholder="Username" required value="<?php echo e(old('username',@$data->username)); ?>">
        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    
    <div class="form-group">
        <label for="no_hp" class="label-control">No Hp <span class="text-danger">*</span></label>
        <div class="input-group has-validation">
            <span class="input-group-text" id="inputGroupPrepend">+628</span>
            <input type="text" autocomplete="off" maxlength="200" class="form-control phone" name="no_hp" id="no_hp" required value="<?php echo e(old('no_hp',@$data->no_hp)); ?>">
         </div>
        <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="password" class="label-control">Password
        <?php if(isset($data)): ?>
          <span class="text-danger">*
          Kosongkan Jika Tidak Ingin Mengganti Password
        <?php endif; ?>    
        </span></label>
        <input type="password" autocomplete="off" maxlength="200" class="form-control" name="password" id="password" placeholder="Password">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="password_confirm" class="label-control">Konfirmasi Password
        <?php if(isset($data)): ?>
          <span class="text-danger">*
          Kosongkan Jika Tidak Ingin Mengganti Password
        <?php endif; ?>    
        </span></label>
        <input type="password" autocomplete="off" maxlength="200" class="form-control" name="password_confirm" id="password_confirm" placeholder="Konfirmasi Password">
        <?php $__errorArgs = ['password_confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="level_id" class="label-control">Jabatan <span class="text-danger">*</span></label>
        <select class="form-control select2" name="level_id" id="level_id" tabindex="-1" required>
            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($level->id); ?>" <?php if($level->id == old('level_id',@$data->level_id)): ?> selected <?php endif; ?>><?php echo e($level->nama_level); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['level_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="wrapper">
        <?php if(isset($data)): ?>
            
            <?php if($data->level_id == '4'): ?>
            <div class="form-group">
                <label for="unit_id" class="label-control">Unit <span class="text-danger">*</span></label>
                <select class="form-control select2" name="unit_id" id="unit_id" tabindex="-1" required>
                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($unit->id); ?>" <?php if($unit->id == old('unit_id',@$data->unit_id)): ?> selected <?php endif; ?>><?php echo e($unit->nama_unit); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php endif; ?>

            
            <?php if($data->level_id == '3'): ?>
            <div class="form-group">
                <label for="kelas_id" class="label-control">Unit - Kelas <span class="text-danger">*</span></label>
                <select class="form-control select2" name="kelas_id" id="kelas_id" tabindex="-1" required>
                    <?php $__currentLoopData = $kelases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kelas->id); ?>" <?php if($kelas->id == old('kelas_id',@$data->kelas_id)): ?> selected <?php endif; ?>> <?php echo e($kelas->unit->nama_unit); ?> - <?php echo e($kelas->nama_kelas); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $("#level_id").change(function (e) { 
            const value = $(this).val();

            // Jika Jabatan Satgas, Maka Tampilkan Field Unit
            if(value == '4'){
                $('.wrapper').html(`
                    <div class="form-group">
                        <label for="unit_id" class="label-control">Unit <span class="text-danger">*</span></label>
                        <select class="form-control select2" name="unit_id" id="unit_id" tabindex="-1" required>
                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($unit->id); ?>" <?php if($unit->id == old('unit_id',@$data->unit_id)): ?> selected <?php endif; ?>><?php echo e($unit->nama_unit); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                `);

                $('.select2').select2();
            // Jika Jabatan Guru, Maka Tampilkan Field Kelas
            }else if(value == '3'){
                $('.wrapper').html(`
                    <div class="form-group">
                        <label for="kelas_id" class="label-control">Unit - Kelas <span class="text-danger">*</span></label>
                        <select class="form-control select2" name="kelas_id" id="kelas_id" tabindex="-1" required>
                            <?php $__currentLoopData = $kelases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kelas->id); ?>" <?php if($kelas->id == old('kelas_id',@$data->kelas_id)): ?> selected <?php endif; ?>> <?php echo e($kelas->unit->nama_unit); ?> - <?php echo e($kelas->nama_kelas); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                `);

                $('.select2').select2();
            }else{
                $('.wrapper').html('');
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel\skrining\resources\views/staff/form.blade.php ENDPATH**/ ?>