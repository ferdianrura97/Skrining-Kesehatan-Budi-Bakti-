

<?php $__env->startSection('form-title'); ?>
    <?php if(isset($data)): ?>
        Ubah Data <?php echo e($settings['title']); ?>

    <?php else: ?>
        Tambah Data <?php echo e($settings['title']); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('form'); ?>
    <?php if(isset($data)): ?>
        <input type="hidden" name="_method" value="PUT">
    <?php endif; ?>

    <div class="form-group">
        <label for="unit_id" class="label-control">Unit <span class="text-danger">*</span></label>
        <select class="form-control select2" name="unit_id" id="unit_id" tabindex="-1" required>
            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($unit->id); ?>" <?php if($unit->id == old('unit_id',@$data->unit_id)): ?> selected <?php endif; ?>><?php echo e($unit->nama_unit); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="nama" class="label-control">Nama Kelas <span class="text-danger">*</span></label>
        <input type="text" autocomplete="off" maxlength="200" class="form-control" name="nama_kelas" id="nama_kelas" placeholder="Nama Kelas" required value="<?php echo e(old('nama_kelas',@$data->nama_kelas)); ?>">
        <?php $__errorArgs = ['nama_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel\skrining\resources\views/kelas/edit.blade.php ENDPATH**/ ?>