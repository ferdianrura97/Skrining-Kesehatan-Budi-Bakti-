<?php $__env->startSection('breadcrumb'); ?>
<?php echo $__env->make('layouts.include._breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-sm-12">
     <div class="card">
        <div class="card-header d-flex justify-content-between">
           <div class="header-title">
              <h4 class="card-title"><?php echo e($settings['title']); ?></h4>
            </div>
            <?php if(Helper::cek_akses($settings['title'], 'Tambah')): ?>
               <a href="<?php echo e(route($settings['route'].'.create')); ?>" class="btn btn-sm btn-primary float-right">+ Tambah <?php echo e($settings['title']); ?></a>
            <?php endif; ?>
        </div>
        <div class="card-body">
           <div class="table-responsive">
              <table class="table" data-toggle="data-table">
                 <thead>
                    <tr>
                       <th>No</th>
                       <th>Tanggal</th>
                       <th>Nomor Invoice</th>
                       <th>Supplier</th>
                       <th>Tgl Jatuh Tempo</th>
                       <th>Status</th>
                       <th>Sisa Tagihan</th>
                       <th>Total Tagihan</th>
                       <th>Aksi</th>
                    </tr>
                 </thead>
                 <tbody>
                   <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                     <td><?php echo e($loop->iteration); ?></td>
                     <td><?php echo e($data->tgl_transaksi); ?></td>
                     <td class="text-primary text-center">
                        <a href="<?php echo e(route($settings['route'].'.show', $data->id)); ?>"><?php echo e($data->no_transaksi); ?></a>
                     </td>
                     <td><?php echo e($data->supplier->nama_supplier); ?></td>
                     <td><?php echo e($data->tgl_jatuh_tempo); ?></td>
                     <td>
                        <button class="btn btn-xs btn-<?php echo e($data->status_button); ?>"><?php echo e($data->status); ?></button>
                     </td>
                     <td>Rp. <?php echo e(number_format($data->sisa_tagihan)); ?></td>
                     <td>Rp. <?php echo e(number_format($data->total)); ?></td>
                     <?php echo $__env->make('layouts.include.basic-action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tfoot>
              </table>
           </div>
        </div>
     </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/pembelian/index.blade.php ENDPATH**/ ?>