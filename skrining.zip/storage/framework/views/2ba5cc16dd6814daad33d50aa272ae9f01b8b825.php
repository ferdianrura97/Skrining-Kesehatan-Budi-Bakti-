<?php $__env->startSection('form-title'); ?>
    <?php if(isset($data)): ?>
        Ubah Data <?php echo e($settings['title']); ?>

    <?php else: ?>
        Tambah Data <?php echo e($settings['title']); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('form'); ?>
    <?php if(isset($data)): ?>
        <input type="hidden" name="_method" value="PUT">
    <?php endif; ?>
    <div class="form-group">
      <label for="nama_produk" class="form-label">Nama Produk <span class="text-danger">*</span> </label>
      <input class="form-control" type="text" name="nama_produk" required value="<?php echo e(old('nama_produk',@$data->nama_produk)); ?>">
      <?php $__errorArgs = ['nama_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger"><?php echo e($message); ?></strong>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
      <label for="satuan" class="form-label">Satuan <span class="text-danger">*</span> </label>
      <input class="form-control" type="text" name="satuan" required value="<?php echo e(old('satuan',@$data->satuan)); ?>">
      <?php $__errorArgs = ['satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger"><?php echo e($message); ?></strong>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <?php if(!isset($data)): ?>
    <div class="form-group">
      <label for="stok" class="form-label">Stok Awal <span class="text-danger">*</span> </label>
      <input class="form-control" type="number" name="stok" required value="<?php echo e(old('stok')); ?>">
      <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger"><?php echo e($message); ?></strong>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <?php endif; ?>

    <div class="form-group">
      <label for="harga_jual" class="form-label">Harga Jual <span class="text-danger">*</span> </label>
      <input class="form-control money" type="text" name="harga_jual" required value="<?php echo e(old('harga_jual',@$data->harga_jual)); ?>">
      <?php $__errorArgs = ['harga_jual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger"><?php echo e($message); ?></strong>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
      <label for="harga_beli" class="form-label">Harga Beli <span class="text-danger">*</span> </label>
      <input class="form-control money" type="text" name="harga_beli" required value="<?php echo e(old('harga_beli',@$data->harga_beli)); ?>">
      <?php $__errorArgs = ['harga_beli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger"><?php echo e($message); ?></strong>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/produk/form.blade.php ENDPATH**/ ?>