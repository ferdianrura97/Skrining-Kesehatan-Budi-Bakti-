<?php $__env->startSection('breadcrumb'); ?>
<?php echo $__env->make('layouts.include._breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
   <div class="col-md-12">
      <div class="card">
         <div class="card-body">
            <form style="width: 100%;" method="GET">
               <div class="form-group">
                   <div class="row">

                       <div class="col-md-6">
                           <label for="periode" class="form-control-label mb-2">Tanggal Periode : </label>
                           <input class="form-control" type="text" autocomplete="off" name="periode" id="periode" value="<?php echo e(@$request->get('periode')); ?>">
                       </div>

                       <div class="col-md-4">
                           <label for="status" class="form-control-label mb-2">Pilih Status : </label>
                           <select name="status" class="form-control select2" id="perangkat_daerah_id"
                               data-toggle="select">
                               <option value="">Pilih Status</option>
                               <option value="sehat" <?php if($request->get('status') == 'sehat' ): ?> SELECTED <?php endif; ?> >Sehat</option>
                               <option value="sakit" <?php if($request->get('status') == 'sakit' ): ?> SELECTED <?php endif; ?> >Sakit</option>
                               <option value="karantina" <?php if($request->get('status') == 'karantina' ): ?> SELECTED <?php endif; ?> >Karantina</option>
                               <option value="positif" <?php if($request->get('status') == 'positif' ): ?> SELECTED <?php endif; ?> >Positif</option>
                           </select>
                       </div>

                   </div>
               </div>
               <div class="row mt-3">
                   <div class="col-md-12">
                       <button class="btn btn-primary btn-sm" type="submit">Tampil</button>
                       <a href="<?php echo e(url()->current()); ?>" class="btn btn-primary btn-sm">Refresh</a>
                   </div>
               </div>
           </form>
         </div>
      </div>
   </div>
</div>

<div class="row">
  <div class="col-sm-12">
     <div class="card">
        <div class="card-header d-flex justify-content-between">
           <div class="header-title">
              <h4 class="card-title"><?php echo e($settings['title']); ?></h4>
            </div>
        </div>
        <div class="card-body">
           <div class="table-responsive">
              <table id="datatable-print" class="table">
                 <thead>
										<tr>
											<th>No</th>
											<th>Nama Siswa</th>
											<th>NISN</th>
											<th>Unit - Kelas</th>
											<th>Tgl Pengisian</th>
											<th>Status Kesehatan</th>
										</tr>
                 </thead>
                 <tbody>
									<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
											<td><?php echo e($loop->iteration); ?></td>
											<td><?php echo e($data->siswa->nama); ?></td>
											<td><?php echo e($data->siswa->nomor_induk); ?></td>
											<td><?php echo e($data->siswa->kelas->unit->nama_unit); ?> - <?php echo e($data->siswa->kelas->nama_kelas); ?></td>
											<td><?php echo e($data->tgl_pengisian); ?></td>
											<td align="center"><?php echo $data->desain_status; ?></td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
              </table>
           </div>
        </div>
     </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<script>
$(document).ready(function() {
    // FLATPICKR
      flatpickr('#periode', {
         mode: "range",
      });
      $("#periode").prop('readonly', false)
      $("#periode").prop('required', true)
} );
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel\skrining\resources\views/laporan/skrining.blade.php ENDPATH**/ ?>