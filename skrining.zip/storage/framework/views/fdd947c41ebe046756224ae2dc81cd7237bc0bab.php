<?php if(Session::has('success')): ?>
    <script>
      swal("Berhasil", "<?php echo e(Session::get('success')); ?>", "success");
    </script>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <script>
      swal("Gagal", "<?php echo e(Session::get('error')); ?>", "error");
    </script>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
  <script>
    swal("Ops", "<?php echo e(Session::get('warning')); ?>", "warning");
  </script>
<?php endif; ?>

<?php if(Session::has('info')): ?>
  <script>
    swal("Informasi", "<?php echo e(Session::get('info')); ?>", "info");
  </script>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/layouts/include/message.blade.php ENDPATH**/ ?>