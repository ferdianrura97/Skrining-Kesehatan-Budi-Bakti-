<?php $__env->startSection('form-title'); ?>
<?php if(isset($data)): ?>
Ubah Data <?php echo e($settings['title']); ?>

<?php else: ?>
Tambah Data <?php echo e($settings['title']); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('form'); ?>
<?php if(isset($data)): ?>
<input type="hidden" name="_method" value="PUT">
<?php endif; ?>
<div class="form-group">
    <label for="nama_level" class="label-control">Nama Jabatan <span class="text-danger">*</span></label>
    <input type="text" maxlength="200" class="form-control" name="nama_level" id="nama_level" placeholder="Nama Jabatan"
        required value="<?php echo e(old('nama_level',@$data->nama_level)); ?>">
    <?php $__errorArgs = ['nama_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <strong class="text-danger"><?php echo e($message); ?></strong>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group table-responsive">
    <table class="table">
        <thead>
            <tr>
                <th>
                    <input type="checkbox" class="check_all" data-target=".pilihan" id="pilih">
                    <label for="pilih">Pilih Semua</label>
                </th>

                <th>
                    Menu
                </th>

                <th>
                    Aksi
                </th>
            </tr>
        </thead>
        <tbody>
            <?php
            $nama = "";
            $pil = 0;
            ?>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($nama != $menu->nama_menu): ?>
            <?php

            $pil ++;
            ?>
            <?php if($key > 0): ?>
            </tr>

            <?php endif; ?>
            <tr>
                <td>
                    <input type="checkbox" class="check_all pilihan" data-target=".pilihan-<?php echo e($pil); ?>">
                </td>
                <td>
                    <?php echo e($menu->nama_menu); ?>


                </td>
                <td>
                    <input type="checkbox" <?php if(isset($levelMenus) && in_array($menu->id,$levelMenus)): ?> checked <?php endif; ?>
                    id="menu-<?php echo e($menu->id); ?>" name="menu_id[]" class="pilihan pilihan-<?php echo e($pil); ?>"
                    value="<?php echo e($menu->id); ?>">
                    <label for="menu-<?php echo e($menu->id); ?>"><?php echo e($menu->aksi_menu); ?></label>
                    <?php
                    $nama = $menu->nama_menu;

                    ?>
                    <?php else: ?>
                    <input type="checkbox" <?php if(isset($levelMenus) && in_array($menu->id,$levelMenus)): ?> checked <?php endif; ?>
                    id="menu-<?php echo e($menu->id); ?>" name="menu_id[]" class="pilihan pilihan-<?php echo e($pil); ?>"
                    value="<?php echo e($menu->id); ?>">
                    <label for="menu-<?php echo e($menu->id); ?>"><?php echo e($menu->aksi_menu); ?></label>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $(document).on('change', '.check_all', function (e) {
            $($(this).data('target')).prop('checked', $(this).is(':checked'));
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/level/form.blade.php ENDPATH**/ ?>