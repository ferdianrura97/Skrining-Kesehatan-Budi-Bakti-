<?php $__env->startSection('form-title'); ?>
    <?php if(isset($data)): ?>
        Ubah Data <?php echo e($settings['title']); ?>

    <?php else: ?>
        Tambah Data <?php echo e($settings['title']); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
  .form-control{
    padding: .5rem 0.5rem !important;
  }
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('form'); ?>
    <?php if(isset($data)): ?>
        <input type="hidden" name="_method" value="PUT">
    <?php endif; ?>
    <div class="row">
      <div class="col-md-4">
        <div class="form-group">
          <label for="nama_produk" class="form-label">Pilih Pelanggan <span class="text-danger">*</span> </label>
          <select class="form-control select2" name="pelanggan_id" tabindex="-1" required>
            <option value="">Pilih Pelanggan</option>
            <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($pelanggan->id); ?>" <?php if($pelanggan->id == old('pelanggan_id',@$data->pelanggan_id)): ?> selected <?php endif; ?>><?php echo e($pelanggan->nama_pelanggan); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <?php $__errorArgs = ['pelanggan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
          <label for="alamat" class="form-label">Alamat</label>
          <textarea name="alamat" class="form-control" readonly><?php echo e(old('alamat',@$data->alamat)); ?></textarea>
          <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>

      <div class="col-md-3">
        <div class="form-group">
          <label for="no_transaksi" class="form-label">No Transaksi <span class="text-danger">*</span> </label>
          <input class="form-control" type="text" value="<?php echo e((@$data) ? $data->no_transaksi : \Helper::generateNoPenjualan()); ?>" name="no_transaksi" required readonly>
          <?php $__errorArgs = ['no_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
          <label for="tgl_transaksi" class="form-label">Tgl Transkasi <span class="text-danger">*</span> </label>
          <input class="form-control" type="date" name="tgl_transaksi" required value="<?php echo e(date('Y-m-d')); ?>">
          <?php $__errorArgs = ['tgl_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
          <label for="tgl_jatuh_tempo" class="form-label">Tgl Jatuh Tempo <span class="text-danger">*</span> </label>
          <input class="form-control" type="date" name="tgl_jatuh_tempo" required value="<?php echo e(date('Y-m-d')); ?>">
          <?php $__errorArgs = ['tgl_jatuh_tempo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
      </div>
      <div class="col-md-5">
        <div class="form-group text-end primary">
          <h3>Total <span style="color: #3a57e8" id="total_tagihan">Rp. 0</span></h3>
        </div>
      </div>
    </div>

    <div class="row mb-5">
      <div class="col-md-12">
        <table class="table" style="font-size: 11px;">
          <thead>
            <tr>
              <th width="25%">Produk<span class="text-danger">*</span></th>
              <th width="10%">Qty<span class="text-danger">*</span></th>
              <th width="10%">Satuan<span class="text-danger">*</span></th>
              <th width="13%">Harga Satuan<span class="text-danger">*</span></th>
              <th width="10%">Diskon (Rp)</th>
              <th width="10%">Pajak (%)</th>
              <th width="20%">Sub Total<span class="text-danger">*</span></th>
              <th width="2%"></th>
            </tr>
          </thead>
          <tbody>
            <?php if(isset($data)): ?>
            <?php $__currentLoopData = $data->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <select class="form-control select2" name="produk_id[]" tabindex="-1" required>
                  <option value="">Pilih Produk</option>
                  <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($produk->id); ?>" <?php if($produk->id == $detail->produk_id): ?> selected <?php endif; ?> ><?php echo e($produk->nama_produk); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['produk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control number" type="text" name="qty[]" required value="<?php echo e($detail->qty); ?>">
                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control" type="text" name="satuan[]" required value="<?php echo e($detail->produk->satuan); ?>" readonly>
                <?php $__errorArgs = ['satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control money" type="text" name="harga_jual[]" required value="<?php echo e($detail->harga); ?>">
                <?php $__errorArgs = ['harga_jual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control money" type="text" name="diskon[]" value="<?php echo e($detail->diskon); ?>">
                <?php $__errorArgs = ['diskon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control number" type="text" name="pajak[]" value="<?php echo e($detail->pajak); ?>">
                <?php $__errorArgs = ['pajak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control money" type="text" name="jumlah[]" value="<?php echo e($detail->sub_total); ?>" >
                <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <a class="removeButton"><i class="fa-solid fa-minus"></i></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php else: ?>
            <tr>
              <td>
                <select class="form-control select2" name="produk_id[]" tabindex="-1" required>
                  <option value="">Pilih Produk</option>
                  <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($produk->id); ?>"><?php echo e($produk->nama_produk); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['produk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control number" type="text" name="qty[]" required value="1">
                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control" type="text" name="satuan[]" required readonly>
                <?php $__errorArgs = ['satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control money" type="text" name="harga_jual[]" required>
                <?php $__errorArgs = ['harga_jual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control money" type="text" name="diskon[]">
                <?php $__errorArgs = ['diskon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control number" type="text" name="pajak[]">
                <?php $__errorArgs = ['pajak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <input class="form-control money" type="text" name="jumlah[]" >
                <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <strong class="text-danger"><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </td>
              <td>
                <a class="removeButton"><i class="fa-solid fa-minus"></i></a>
              </td>
            </tr>


            <?php endif; ?>


          </tbody>
        </table>
        <button type="button" class="btn btn-sm btn-primary addButton"> <i class="fa-solid fa-plus"></i> Tambah Produk </button>
      </div>
    </div>

    <div class="row mb-5">
      <div class="col-md-3">
        <label for="catatan" class="form-label">Catatan </label>
        <textarea name="catatan" class="form-control"><?php echo e(old('catatan',@$data->catatan)); ?></textarea>
        <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <strong class="text-danger"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="offset-md-5 col-md-4">
        <div class="row">
          <div class="col-md-6">
            <p> Sub Total </p>
            <p> Diskon </p>
            <p> Pajak </p>
            <p> Total </p>
            <p class="fw-bolder"> Uang Muka (Rp.) </p>
          </div>
          <div class="col-md-6 text-end">
            <p id="sub_total"> 0 </p>
            <p id="diskon"> 0 </p>
            <p id="pajak"> 0 </p>
            <p id="total"> 0 </p>
            <input style="width: 80%;" class="form-control money float-end text-end" type="text" name="uang_muka" value="<?php echo e(old('uang_muka',@$data->uang_muka)); ?>">
          </div>
          
          <div class="col-md-6">
            <h5 style="color: #8A92A5">Sisa Tagihan</h5>
          </div>
          <div class="col-md-6 text-end">
            <h5 style="color: #8A92A5" id="sisa_tagihan"> </h5>
          </div>
        </div>
      </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  $(document).ready(function(){

    // Function Wrapper

    /*
    Function Convert String To Number
    */
    function toNumber(string){
      return parseInt(string.replace(/\./g, ''))
    }

    /*
    Function Format Uang
    */
    function money(x) {
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    /*
    Function Hitung Keseluruhan Produk
    */
    function hitungTotal(){
      let total = 0;
      $('input[name="jumlah[]"]').each(function(index, el) {
        total += toNumber($(this).val());
      });

      let diskon = 0;
      $('input[name="diskon[]"]').each(function(index, el) {
        if($(this).val())
          diskon += toNumber($(this).val());
      });

      let subTotal = 0;
      let pajakTtl = 0;
      $('input[name="harga_jual[]"]').each(function(index, el) {
        let harga = toNumber($(this).val());
        let qty = toNumber($(this).parent().parent().find('input[name="qty[]"]').val());
        let diskon = toNumber($(this).parent().parent().find('input[name="diskon[]"]').val());
        let pajak = toNumber($(this).parent().parent().find('input[name="pajak[]"]').val());

        subTotal += harga * qty;

        if(pajak){
          if(diskon)
            pajakTtl += pajak * ((harga * qty) - diskon) / 100;
          else
            pajakTtl += pajak * ((harga * qty)) / 100;
        }
      });
      
      $('#total').html("Rp. " + money(total));
      $('#diskon').html("Rp. " + money(diskon));
      $('#pajak').html("Rp. " + money(pajakTtl));
      $('#sub_total').html("Rp. " + money(subTotal));

      const uangMuka = toNumber($('input[name="uang_muka"]').val());
      const sisaTagihan = total - (uangMuka ? uangMuka : 0);
      $('#sisa_tagihan').html("Rp. " + money(sisaTagihan));
      $('#total_tagihan').html("Rp. " + money(total));
    }

    /*
    Function Hitung Per Produk
    */
    function hitungJumlah(el){
      const harga = toNumber($(el).parent().parent().find('input[name="harga_jual[]"]').val());
      const qty = $(el).parent().parent().find('input[name="qty[]"]').val();
      const diskon = toNumber($(el).parent().parent().find('input[name="diskon[]"]').val());
      const pajak = $(el).parent().parent().find('input[name="pajak[]"]').val();

      let jumlah = (harga * qty);

      if(diskon)
        jumlah -= diskon

      if(pajak)
        jumlah = jumlah + (pajak * jumlah / 100);

      $(el).parent().parent().find('input[name="jumlah[]"]').val(jumlah);
      $(el).parent().parent().find('input[name="jumlah[]"]').trigger('input');

      hitungTotal();
    }

    function init(){
      $('.money').mask('000.000.000.000.000', {reverse: true});
      $('.phone').mask('0000-0000');
      $('.number').mask('0000000000000');

      $('select[name="produk_id[]"]').change(function (e) { 
        const value = this.value;
        const el = $(this);
        $.ajax({
          type: "get",
          url: "<?php echo e(url('api/produk')); ?>/"+value,
          success: function (res) {
            const data = res.data;
            if(!data.stok){
              alert(`Stok Untuk Produk ${data.nama_produk} Habis`)
              el.val('')
            }else{
              el.parent().parent().find('input[name="satuan[]"]').val(data.satuan);
              el.parent().parent().find('input[name="harga_jual[]"]').val(data.harga_jual);
              el.parent().parent().find('input[name="harga_jual[]"]').trigger('input');
              el.parent().parent().find('input[name="qty[]"]').attr('max', data.stok);

              hitungJumlah(el);
            }
          }
        });
      });

      $('input[name="qty[]"]').keyup(function (e) { 
        const produkId = $(this).parent().parent().find('select[name="produk_id[]"]').val();
        const value = $(this);
        if(produkId){
          $.ajax({
            type: "get",
            url: "<?php echo e(url('api/produk')); ?>"+'/'+produkId,
            success: function (res) {
              const data = res.data;
              if(value.val()){
                if(value.val() > data.stok){
                  alert(`Stok Untuk Produk ${data.nama_produk} Tersisa ${data.stok}`)
                  value.val(data.stok)
                }
                hitungJumlah(value);
              }
            }
          });
        }
      });

      $('input[name="harga_jual[]"]').keyup(function (e) { 
        hitungJumlah(this);
      });

      $('input[name="diskon[]"]').keyup(function (e) { 
        hitungJumlah(this);
      });

      $('input[name="pajak[]"]').keyup(function (e) { 
        hitungJumlah(this);
      }); 

      $('input[name="uang_muka"]').keyup(function (e) { 
        hitungTotal();
      }); 
    }

    // End Function Wrapper

    $('aside.sidebar').addClass('sidebar-mini');

    let addButton = $('.addButton');
    let wrapper = $('tbody');
    let fieldHtml = `
    <tr>
        <td>
            <select class="form-control select2" name="produk_id[]" tabindex="-1" required>
              <option value="">Pilih Produk</option>
              <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($produk->id); ?>"><?php echo e($produk->nama_produk); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['produk_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>
        <td>
            <input class="form-control number" type="text" name="qty[]" required value="1">
            <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>
        <td>
            <input class="form-control" type="text" name="satuan[]" required readonly>
            <?php $__errorArgs = ['satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>
        <td>
            <input class="form-control money" type="text" name="harga_jual[]" required>
            <?php $__errorArgs = ['harga_jual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>
        <td>
            <input class="form-control money" type="text" name="diskon[]">
            <?php $__errorArgs = ['diskon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>
        <td>
            <input class="form-control number" type="text" name="pajak[]">
            <?php $__errorArgs = ['pajak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>
        <td>
            <input class="form-control money" type="text" name="jumlah[]">
            <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong class="text-danger"><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </td>
        <td>
          <a class="removeButton"><i class="fa-solid fa-minus"></i></a>
        </td>
    </tr>
    `;

    $(addButton).click(function(){
      $(wrapper).append(fieldHtml); //Add field html

      init();
    });

    $(wrapper).on('click', '.removeButton', function(e){
        e.preventDefault();
        $(this).parent().parent().remove(); //Remove field html
    });

    $('select[name="pelanggan_id"]').change(function (e) { 
      $.ajax({
        type: "get",
        url: "<?php echo e(url('api/pelanggan')); ?>"+"/"+$(this).val(),
        success: function (res) {
          $('textarea[name="alamat"]').val(res.data.alamat);
        }
      });
      
    });

    init();
    
    let isEditForm = "<?php echo e(@$data); ?>";
    if(isEditForm.length){
      hitungTotal();
    }

    
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/penjualan/form.blade.php ENDPATH**/ ?>