<?php $__env->startSection('breadcrumb'); ?>
<?php echo $__env->make('layouts.include._breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 col-lg-12">
        <div class="row row-cols-1">
            <div class="overflow-hidden d-slider1 ">
                <ul class="p-0 m-0 mb-2 swiper-wrapper list-inline">
                    <li class="swiper-slide card card-slide" data-aos="fade-up" data-aos-delay="700">
                        <div class="card-body">
                            <div class="progress-widget">
                                <div id="circle-progress-01"
                                    class="text-center circle-progress-01 circle-progress circle-progress-primary"
                                    data-min-value="0" data-max-value="100" data-value="90"
                                    data-type="percent">
                                    <svg class="card-slie-arrow " width="24" height="24px"
                                        viewBox="0 0 24 24">
                                        <path fill="currentColor"
                                            d="M5,17.59L15.59,7H9V5H19V15H17V8.41L6.41,19L5,17.59Z" />
                                    </svg>
                                </div>
                                <div class="progress-detail">
                                    <p class="mb-2">Total Sales</p>
                                    <h4 class="counter"><?php echo e($datas['total_penjualan']); ?></h4>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="swiper-slide card card-slide" data-aos="fade-up" data-aos-delay="800">
                        <div class="card-body">
                            <div class="progress-widget">
                                <div id="circle-progress-02"
                                    class="text-center circle-progress-01 circle-progress circle-progress-info"
                                    data-min-value="0" data-max-value="100" data-value="80"
                                    data-type="percent">
                                    <svg class="card-slie-arrow " width="24" height="24"
                                        viewBox="0 0 24 24">
                                        <path fill="currentColor"
                                            d="M19,6.41L17.59,5L7,15.59V9H5V19H15V17H8.41L19,6.41Z" />
                                    </svg>
                                </div>
                                <div class="progress-detail">
                                    <p class="mb-2">Today</p>
                                    <h4 class="counter"><?php echo e($datas['penjualan_hari_ini']); ?></h4>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li class="swiper-slide card card-slide" data-aos="fade-up" data-aos-delay="900">
                        <div class="card-body">
                            <div class="progress-widget">
                                <div id="circle-progress-03"
                                    class="text-center circle-progress-01 circle-progress circle-progress-primary"
                                    data-min-value="0" data-max-value="100" data-value="70"
                                    data-type="percent">
                                    <svg class="card-slie-arrow " width="24" viewBox="0 0 24 24">
                                        <path fill="currentColor"
                                            d="M19,6.41L17.59,5L7,15.59V9H5V19H15V17H8.41L19,6.41Z" />
                                    </svg>
                                </div>
                                <div class="progress-detail">
                                    <p class="mb-2">Total Cost</p>
                                    <h4 class="counter"><?php echo e($datas['total_pengeluaran']); ?></h4>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
                <div class="swiper-button swiper-button-next"></div>
                <div class="swiper-button swiper-button-prev"></div>
            </div>
        </div>
    </div>
    <div class="col-md-12 col-lg-12">
        <div class="row">
            <div class="col-md-12">
                <div class="card" data-aos="fade-up" data-aos-delay="800">
                    <div class="flex-wrap card-header d-flex justify-content-between align-items-center">
                        <div class="header-title">
                            <h4 class="card-title">$855.8K</h4>
                            <p class="mb-0">Gross Sales</p>
                        </div>
                        <div class="d-flex align-items-center align-self-center">
                            <div class="d-flex align-items-center text-primary">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" viewBox="0 0 24 24"
                                    fill="currentColor">
                                    <g>
                                        <circle cx="12" cy="12" r="8" fill="currentColor"></circle>
                                    </g>
                                </svg>
                                <div class="ms-2">
                                    <span class="text-secondary">Sales</span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center ms-3 text-info">
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" viewBox="0 0 24 24"
                                    fill="currentColor">
                                    <g>
                                        <circle cx="12" cy="12" r="8" fill="currentColor"></circle>
                                    </g>
                                </svg>
                                <div class="ms-2">
                                    <span class="text-secondary">Cost</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="d-main" class="d-main"></div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-xl-4">
                <div class="card" data-aos="fade-up" data-aos-delay="900">
                    <div class="flex-wrap card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title">Earnings</h4>
                        </div>
                        <div class="dropdown">
                            <p>Bulan Ini</p>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="flex-wrap d-flex align-items-center justify-content-between">
                            <div id="myChart" class="col-md-8 col-lg-8 myChart"></div>
                            <div class="d-grid gap col-md-4 col-lg-4">
                                <div class="d-flex align-items-start">
                                    <svg class="mt-2" xmlns="http://www.w3.org/2000/svg" width="14"
                                        viewBox="0 0 24 24" fill="#3a57e8">
                                        <g>
                                            <circle cx="12" cy="12" r="8" fill="#3a57e8"></circle>
                                        </g>
                                    </svg>
                                    <div class="ms-3">
                                        <span class="text-secondary">Penjualan</span>
                                        <h6><?php echo e($datas['penjualan_bulan_ini']); ?></h6>
                                    </div>
                                </div>
                                <div class="d-flex align-items-start">
                                    <svg class="mt-2" xmlns="http://www.w3.org/2000/svg" width="14"
                                        viewBox="0 0 24 24" fill="#4bc7d2">
                                        <g>
                                            <circle cx="12" cy="12" r="8" fill="#4bc7d2"></circle>
                                        </g>
                                    </svg>
                                    <div class="ms-3">
                                        <span class="text-secondary">Pengeluaran</span>
                                        <h6><?php echo e($datas['pengeluaran_bulan_ini']); ?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-xl-8">
                <div class="card" data-aos="fade-up" data-aos-delay="600">
                    <div class="flex-wrap card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="mb-2 card-title">Activity overview</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $datas['aktifitas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-2  d-flex profile-media align-items-top">
                            <div class="mt-1 profile-dots-pills border-primary"></div>
                            <div class="ms-4">
                                <h6 class="mb-1 "><?php echo e($data->action); ?></h6>
                                <span class="mb-0"><?php echo e($data->created_at->diffForHumans()); ?></span>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        if (document.querySelectorAll('#d-main').length) {
            const options = {
                series: [{
                    name: 'Penjualan',
                    data: <?php echo json_encode(Helper::mainChart()['a']); ?>

                }, {
                    name: 'Pengeluaran',
                    data: <?php echo json_encode(Helper::mainChart()['b']); ?>

                }],
                chart: {
                    fontFamily: '"Inter", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"',
                    height: 245,
                    type: 'area',
                    toolbar: {
                        show: false
                    },
                    sparkline: {
                        enabled: false,
                    },
                },
                colors: ["#3a57e8", "#4bc7d2"],
                dataLabels: {
                    enabled: false
                },
                stroke: {
                    curve: 'smooth',
                    width: 3,
                },
                yaxis: {
                    show: false,
                    labels: {
                    show: true,
                    minWidth: 19,
                    maxWidth: 19,
                    style: {
                        colors: "#8A92A6",
                    },
                    offsetX: 20,
                    },
                },
                legend: {
                    show: false,
                },
                xaxis: {
                    labels: {
                        minHeight:22,
                        maxHeight:22,
                        show: true,
                        style: {
                            colors: "#8A92A6",
                        },
                    },
                    lines: {
                        show: false  //or just here to disable only x axis grids
                    },
                    categories: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                },
                grid: {
                    show: false,
                },
                fill: {
                    type: 'gradient',
                    gradient: {
                        shade: 'dark',
                        type: "vertical",
                        shadeIntensity: 0,
                        gradientToColors: undefined, // optional, if not defined - uses the shades of same color in series
                        inverseColors: true,
                        opacityFrom: .4,
                        opacityTo: .1,
                        stops: [0, 50, 80],
                        colors: ["#3a57e8", "#4bc7d2"]
                    }
                },
                tooltip: {
                    enabled: true,
                },
            };

            const chart = new ApexCharts(document.querySelector("#d-main"), options);
            chart.render();
            document.addEventListener('ColorChange', (e) => {
                console.log(e)
                const newOpt = {
                colors: [e.detail.detail1, e.detail.detail2],
                fill: {
                    type: 'gradient',
                    gradient: {
                        shade: 'dark',
                        type: "vertical",
                        shadeIntensity: 0,
                        gradientToColors: [e.detail.detail1, e.detail.detail2], // optional, if not defined - uses the shades of same color in series
                        inverseColors: true,
                        opacityFrom: .4,
                        opacityTo: .1,
                        stops: [0, 50, 60],
                        colors: [e.detail.detail1, e.detail.detail2],
                    }
                },
            }
                chart.updateOptions(newOpt)
            })
            }

            if (document.querySelectorAll('#myChart').length) {
                const options = {
                    series: <?php echo json_encode($datas['persen_penjualan_pengeluaran']); ?>,
                    chart: {
                    height: 230,
                    type: 'radialBar',
                },
                colors: ["#4bc7d2", "#3a57e8"],
                plotOptions: {
                    radialBar: {
                    hollow: {
                        margin: 10,
                        size: "50%",
                    },
                    track: {
                        margin: 10,
                        strokeWidth: '50%',
                    },
                    dataLabels: {
                        show: false,
                    }
                    }
                },
                labels: ['Apples', 'Oranges'],
                };
                if(ApexCharts !== undefined) {
                    const chart = new ApexCharts(document.querySelector("#myChart"), options);
                    chart.render();
                    document.addEventListener('ColorChange', (e) => {
                        const newOpt = {colors: [e.detail.detail2, e.detail.detail1],}
                        chart.updateOptions(newOpt)
                    
                    })
                }
            }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/dashboard.blade.php ENDPATH**/ ?>