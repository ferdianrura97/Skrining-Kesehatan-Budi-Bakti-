<form action="<?php echo e(route('siswa.handleLogin')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="nomor_induk" />
    <input type="password" name="password" />
    <button type="submit">Log in</button>
</form><?php /**PATH D:\laragon\www\laravel\skrining\resources\views/siswa/login.blade.php ENDPATH**/ ?>