<?php $__env->startSection('form-title'); ?>
    <?php if(isset($data)): ?>
        Ubah Data <?php echo e($settings['title']); ?>

    <?php else: ?>
        Tambah Data <?php echo e($settings['title']); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('form'); ?>
    <?php if(isset($data)): ?>
        <input type="hidden" name="_method" value="PUT">
    <?php endif; ?>
    <div class="form-group">
      <label for="kode_akun" class="form-label">Kode Akun <span class="text-danger">*</span> </label>
      <input class="form-control" type="text" name="kode_akun" required value="<?php echo e(old('kode_akun',@$data->kode_akun)); ?>">
      <?php $__errorArgs = ['kode_akun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger"><?php echo e($message); ?></strong>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
      <label for="nama_akun" class="form-label">Nama Akun <span class="text-danger">*</span> </label>
      <input class="form-control" type="text" name="nama_akun" required value="<?php echo e(old('nama_akun',@$data->nama_akun)); ?>">
      <?php $__errorArgs = ['nama_akun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger"><?php echo e($message); ?></strong>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
      <label for="kategori_akun_id" class="label-control">Kategori Akun <span class="text-danger">*</span></label>
      <select class="form-control select2" name="kategori_akun_id" id="kategori_akun_id" tabindex="-1" required>
          <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($kategori->id); ?>" <?php if($kategori->id == old('kategori_akun_id',@$data->kategori_akun_id)): ?> selected <?php endif; ?>><?php echo e($kategori->nama_kategori); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <?php $__errorArgs = ['kategori_akun_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <strong class="text-danger"><?php echo e($message); ?></strong>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/akun-kas/form.blade.php ENDPATH**/ ?>