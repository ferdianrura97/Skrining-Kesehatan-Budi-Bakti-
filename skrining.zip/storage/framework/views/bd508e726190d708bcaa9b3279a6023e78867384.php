<?php $__env->startSection('breadcrumb'); ?>
<?php echo $__env->make('layouts.include._breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-sm-12">
     <div class="card">
        <div class="card-header d-flex justify-content-between">
           <div class="header-title">
              <h4 class="card-title"><?php echo e($settings['title']); ?></h4>
            </div>
            <?php if(Helper::cek_akses($settings['title'], 'Tambah')): ?>
               <a href="<?php echo e(route($settings['route'].'.create')); ?>" class="btn btn-sm btn-primary float-right">+ Tambah <?php echo e($settings['title']); ?></a>
            <?php endif; ?>
        </div>
        <div class="card-body">
           <div class="table-responsive">
              <table id="datatable" class="table" data-toggle="data-table">
                 <thead>
                    <tr>
                       <th>No </th>
                       <th>Level </th>
                       <th>Aksi</th>
                    </tr>
                 </thead>
                 <tbody>
                   <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($data->nama_level); ?></td>
                     <?php echo $__env->make('layouts.include.basic-action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tfoot>
              </table>
           </div>
        </div>
     </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/akuntansi/resources/views/level/index.blade.php ENDPATH**/ ?>