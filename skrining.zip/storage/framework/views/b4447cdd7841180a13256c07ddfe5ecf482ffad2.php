<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php echo $__env->make('layouts.include._breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
      <div class="col-md-12 col-lg-12">
        <div class="card">
          <div class="card-header d-flex justify-content-between">
            <div class="header-title">
              <h4 class="card-title"><?php echo $__env->yieldContent('form-title'); ?></h4>
            </div>
            
            <a href="<?php echo e(route($settings['route'].'.index')); ?>" class="btn btn-sm btn-warning"><i class="fa fa-arrow-left"></i> Kembali</a>
            
          </div>
          <div class="card-body">
            <form action="<?php echo e($settings['action']); ?>" method="POST" enctype="multipart/form-data" id="form">
              <?php echo csrf_field(); ?>
              <?php echo $__env->yieldContent('form'); ?>
              <div class="form-group">
                  <button class="btn btn-primary" type="submit">Simpan</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\laravel\skrining\resources\views/layouts/app-form.blade.php ENDPATH**/ ?>